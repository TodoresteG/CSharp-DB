﻿namespace ProductShop.Data
{
    public static class Configurator
    {
        public const string ConnectionString = @"Server=DESKTOP-NNVF465\SQLEXPRESS;Database=ProductsShop;Integrated Security=True";
    }
}

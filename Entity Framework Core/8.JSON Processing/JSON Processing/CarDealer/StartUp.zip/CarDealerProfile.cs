﻿namespace CarDealer
{
    using AutoMapper;
    using DTO;
    using Models;

    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            CreateMap<Customer, ExperiencedDriverDTO>()
                .ForMember(x => x.BirthDate, y => y.MapFrom(s => s.BirthDate.ToString("dd/MM/yyyy")));
        }
    }
}

﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-NNVF465\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}
﻿namespace Cinema
{
    using Data.Models;
    using DataProcessor.ImportDtos;

    using AutoMapper;
    using System;
    using System.Globalization;

    public class CinemaProfile : Profile
    {
        // Configure your AutoMapper here if you wish to use it. If not, DO NOT DELETE THIS CLASS
        public CinemaProfile()
        {
        }
    }
}
